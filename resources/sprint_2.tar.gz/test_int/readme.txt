This has test files with integers
Not necessarily integer averages
